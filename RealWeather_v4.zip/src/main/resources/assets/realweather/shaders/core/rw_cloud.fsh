#version 150

// Volumetric clouds: everyday cumulus / stratus, storm tower, anvil, wall cloud and the tornado funnel are all one
// density field that is ray-marched. Terrain depth limits the rays; terrain also receives the cloud shadows.

uniform sampler2D Sampler0;   // noise (R = noise, G = same noise shifted by (37, 17))
uniform sampler2D Sampler1;   // scene depth

uniform mat4 InvViewProj;     // clip -> camera relative world
uniform vec4 CamPos;          // xz = camera in cloud space (wrapped), y = camera height, w = time (ticks)
uniform vec4 SunDir;          // xyz = direction to the sun, w = sun intensity 0..1
uniform vec4 SunCol;          // rgb = sun colour, a = day factor
uniform vec4 AmbCol;          // rgb = ambient sky light, a = dusk
uniform vec4 HorCol;          // rgb = horizon colour, a = cloud shadow strength
uniform vec4 Weather;         // x = cover, y = towering, z = stratus, w = everyday clouds on (0/1)
uniform vec4 Layers;          // x = cumulus base, y = cumulus thickness, z = stratus base, w = stratus thickness
uniform vec4 Params;          // x = max steps, y = draw distance, z = flash scale, w = shadows on (0/1)

uniform vec4 StormA0; uniform vec4 StormB0; uniform vec4 StormC0; uniform vec4 StormD0;
uniform vec4 StormE0; uniform vec4 StormF0; uniform vec4 StormG0;
uniform vec4 StormA1; uniform vec4 StormB1; uniform vec4 StormC1; uniform vec4 StormD1;
uniform vec4 StormE1; uniform vec4 StormF1; uniform vec4 StormG1;

uniform vec4 Flash0; uniform vec4 Flash1; uniform vec4 Flash2; uniform vec4 Flash3;

in vec2 ndc;
out vec4 fragColor;

// Storm layout
//  a = (centre x rel, centre z rel, cloud base y, tower radius)
//  b = (tower growth, anvil growth, mature, dissipation)
//  c = (dir x, dir z, tower height, anvil radius)
//  d = (kind, size, wall drop, active)
//  e = (tornado x rel to centre, tornado z rel to centre, ground y, funnel top y)
//  f = (funnel length 0..1, funnel width 0..1, ground radius, spawn 0..1)
//  g = (flare, category, 0, 0)
struct Storm {
    vec4 a; vec4 b; vec4 c; vec4 d; vec4 e; vec4 f; vec4 g;
};

float sm(float a, float b, float x) {
    float t = clamp((x - a) / (b - a), 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

float noise3(vec3 q) {
    vec3 x = q / 64.0;
    vec3 p = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    vec2 uv = p.xy + vec2(37.0, 17.0) * p.z + f.xy;
    vec2 rg = texture(Sampler0, (uv + 0.5) / 256.0).rg;
    return mix(rg.x, rg.y, f.z);
}

float fbm3(vec3 q, int oct) {
    float s = 0.0;
    float a = 0.5;
    float norm = 0.0;
    for (int i = 0; i < 4; i++) {
        if (i >= oct) {
            break;
        }
        s += a * noise3(q);
        norm += a;
        q = q * 2.0 + vec3(13.7, 7.3, 21.1);
        a *= 0.5;
    }
    return s / norm;
}

// ------------------------------------------------------------------ everyday clouds
float ambientDensity(vec3 pw, int lod) {
    float d = 0.0;
    float cumBase = Layers.x;
    float cumH = Layers.y;
    float h = (pw.y - cumBase) / cumH;
    if (h > 0.0 && h < 1.0) {
        float cover = Weather.x;
        float c = 0.50 * noise3(vec3(pw.x / 8.0, pw.z / 8.0, 0.0))
                + 0.30 * noise3(vec3(pw.x / 4.0, pw.z / 4.0, 5.0))
                + 0.20 * noise3(vec3(pw.x / 2.0, pw.z / 2.0, 9.0));
        float m = sm(1.0 - cover, 1.0 - cover + 0.30, c);
        if (m > 0.0) {
            float dn = fbm3(vec3(pw.x / 3.0, pw.z / 3.0, pw.y / 3.0), lod != 0 ? 2 : 4);
            float hl = pow(max(m, 0.0001), 0.8) * mix(0.30, 1.0, Weather.y) * (0.70 + 0.60 * dn);
            float vp = sm(0.0, 0.06, h) * (1.0 - sm(hl * 0.60, hl + 0.0001, h));
            float shape = vp * sm(0.0, 0.20, m);
            d = clamp((shape - (1.0 - dn) * 0.42 * (0.20 + 0.80 * h)) * 1.9, 0.0, 1.0);
        }
    }
    float hs = (pw.y - Layers.z) / Layers.w;
    float d2 = 0.0;
    if (hs > 0.0 && hs < 1.0 && Weather.z > 0.001) {
        float c2 = 0.6 * noise3(vec3(pw.x / 12.0, pw.z / 12.0, 9.0)) + 0.4 * noise3(vec3(pw.x / 6.0, pw.z / 6.0, 3.0));
        float m2 = sm(1.0 - Weather.z, 1.0 - Weather.z + 0.30, c2);
        if (m2 > 0.0) {
            float vp2 = sm(0.0, 0.25, hs) * (1.0 - sm(0.55, 1.0, hs));
            float dn2 = fbm3(vec3(pw.x / 1.5, pw.z / 1.5, pw.y / 6.0), lod != 0 ? 2 : 3);
            d2 = clamp(m2 * vp2 * (0.55 + 0.9 * dn2) - 0.2, 0.0, 1.0) * 0.9;
        }
    }
    return max(d, d2);
}

// ------------------------------------------------------------------ storm
float stormDensity(Storm s, vec3 p, int lod) {
    if (s.d.w < 0.5) {
        return 0.0;
    }
    float baseY = s.a.z;
    float Rr = s.a.w;
    float G1 = s.b.x;
    float G2 = s.b.y;
    float G3 = s.b.z;
    vec2 dir = s.c.xy;
    float H = s.c.z;
    float AR = s.c.w;
    float size = s.d.y;
    float rx = p.x - s.a.x;
    float rz = p.z - s.a.y;
    float yy = p.y - baseY;
    float hs = 0.35 + 0.65 * G1;
    float topH = H * G1;

    float ext = max(AR * G2 * 1.2, Rr * 2.2);
    if (abs(rx) > ext || abs(rz) > ext || yy < -s.d.z - 100.0 || yy > H + 150.0) {
        return 0.0;
    }

    float t = clamp(yy / H, 0.0, 1.0);
    float rr = Rr * hs * (0.60 + 0.80 * sqrt(t) * (1.0 - 0.55 * t * t * t));
    vec2 cen = dir * (t * t * Rr * 0.9 * hs);
    float dd = length(vec2(rx, rz) - cen);
    float w = fbm3(vec3(rx / 45.0 + 11.0, rz / 45.0, yy / 45.0), lod != 0 ? 2 : 3);
    float warp = (w - 0.5) * 1.5 * rr * (0.40 + 0.60 * t);
    float edge = 1.0 - sm(0.45 * rr, rr, dd + warp);
    float topFall = 1.0 - sm(topH - 0.20 * H, topH + 0.001, yy + (w - 0.5) * 0.15 * H);
    float tower = edge * topFall * sm(-25.0, 10.0, yy);

    float Rb = 1.15 * Rr * hs;
    float dd2 = length(vec2(rx - 0.15 * dir.x * Rr, rz - 0.15 * dir.y * Rr));
    float edge2 = 1.0 - sm(0.25 * Rb, Rb, dd2 + (w - 0.5) * 0.9 * Rb);
    float deck = edge2 * sm(-15.0, 5.0, yy) * (1.0 - sm(30.0, 90.0 * (0.5 + 0.5 * G1), yy + (w - 0.5) * 60.0)) * G1;

    float anvil = 0.0;
    float topA = H * min(1.0, G1 / 0.92) - 20.0;
    if (G2 > 0.01 && yy > topA - 420.0 && yy < topA + 12.0) {
        vec2 o = dir * (Rr * 0.9 * hs);
        float ar = max(AR * G2, 1.0);
        float ux = ((rx - o.x) * dir.x + (rz - o.y) * dir.y) / ar;
        float vx = ((rx - o.x) * (-dir.y) + (rz - o.y) * dir.x) / (ar * 0.85);
        float uu = ux > 0.0 ? ux : ux * 2.4;
        float rad = sqrt(uu * uu + vx * vx);
        if (rad < 1.3) {
            float fib = fbm3(vec3((rx * 0.35 + 3.0) / 50.0, (rz * 0.9) / 50.0, yy / 60.0), lod != 0 ? 2 : 3);
            float inside = 1.0 - sm(0.55, 1.0, rad + (fib - 0.5) * 0.30);
            float core = 1.0 - sm(0.0, 0.85, rad);
            float thick = (110.0 + 190.0 * core) * size * (0.35 + 0.65 * G2);
            float bot = topA - thick + (fib - 0.5) * 80.0;
            float av = sm(bot, bot + 45.0, yy) * (1.0 - sm(topA - 8.0, topA + 4.0, yy));
            anvil = clamp(inside * av * 1.6, 0.0, 1.0) * sm(0.0, 0.08, G2);
        }
    }

    float wall = 0.0;
    if (s.d.x > 0.5 && s.d.x < 1.5 && G3 > 0.01) {
        float wx = s.e.x;
        float wz = s.e.y;
        float wy = (yy + 0.35 * s.d.z) * 2.6;
        float wd = sqrt((rx - wx) * (rx - wx) + (rz - wz) * (rz - wz) + wy * wy);
        float wr = 105.0 * size * G3;
        wall = 1.0 - sm(0.4 * wr, wr, wd + (w - 0.5) * wr * 0.9);
    }

    float d = 1.0 - (1.0 - tower) * (1.0 - deck) * (1.0 - anvil) * (1.0 - wall);
    if (d <= 0.0005) {
        return 0.0;
    }
    float dn = fbm3(vec3(rx / 16.0 + 31.0, rz / 16.0, yy / 16.0), lod != 0 ? 2 : 3);
    float dn2 = fbm3(vec3(rx / 60.0 + 5.0, rz / 60.0, yy / 60.0), 2);
    float er = (1.0 - dn) * 0.55 + (1.0 - dn2) * 0.25;
    return clamp((d - er * (1.0 - d)) * 1.8, 0.0, 1.0);
}

// ------------------------------------------------------------------ tornado funnel (condensation + dust)
vec2 funnelDensity(Storm s, vec3 p) {
    float spawn = s.f.w;
    float len = s.f.x;
    float gy = s.e.z;
    float topY = s.e.w;
    float fullH = topY - gy;
    float rg = s.f.z * 1.8;
    vec2 dir = s.c.xy;
    float time = CamPos.w;
    float px = p.x - s.a.x;
    float pz = p.z - s.a.y;
    float py = p.y;
    float yBot = topY - len * fullH;
    float u = clamp((py - gy) / fullH, 0.0, 1.0);
    float shift = 0.22 * fullH;
    float curve = pow(max(u, 0.0001), 1.6);
    float sway = sin(time * 0.09 + u * 6.0) * rg * 0.5 * (1.0 - u);
    float cx = s.e.x + dir.x * shift * curve + sway * dir.y;
    float cz = s.e.y + dir.y * shift * curve - sway * dir.x;
    float rBot = max(1.8, rg * 0.65) * (0.35 + 0.65 * len);
    float rTop = max(rBot * 1.15, min(rg * s.g.x, 0.50 * fullH));
    float tt = clamp((py - yBot) / max(topY - yBot, 1.0), 0.0, 1.0);
    float r = rBot + (rTop - rBot) * pow(tt, 1.7);
    float dxl = px - cx;
    float dzl = pz - cz;
    float ang = time * 0.05 * (1.5 - u);
    float ca = cos(ang);
    float sa = sin(ang);
    float qx = ca * dxl - sa * dzl;
    float qz = sa * dxl + ca * dzl;
    float dr = length(vec2(dxl, dzl));
    float wn = fbm3(vec3(qx / (r * 0.9 + 3.0) * 30.0 + 17.0, qz / (r * 0.9 + 3.0) * 30.0, py * 0.5 - time * 0.15), 3);
    float edge = 1.0 - sm(0.40 * r, r, dr + (wn - 0.5) * r * 0.9);
    float vert = sm(yBot, yBot + 14.0, py) * (1.0 - sm(topY - 5.0, topY + 5.0, py));
    float cone = clamp(edge * vert * 1.6, 0.0, 1.0) * spawn;
    float dust = (1.0 - sm(0.3 * rg * 2.8, rg * 2.8, dr + (wn - 0.5) * rg))
               * (1.0 - sm(0.0, 22.0 + rg * 0.9, py - gy)) * sm(-3.0, 3.0, py - gy) * sm(0.85, 1.0, len);
    dust = clamp(dust * 1.4, 0.0, 1.0) * spawn;
    return vec2(cone, dust);
}

// ------------------------------------------------------------------ helpers
vec2 boxHit(vec3 ro, vec3 rd, vec3 lo, vec3 hi) {
    vec3 rds = rd + vec3(0.00001) * (1.0 - step(vec3(0.00001), abs(rd)));
    vec3 invd = 1.0 / rds;
    vec3 t0 = (lo - ro) * invd;
    vec3 t1 = (hi - ro) * invd;
    vec3 tmn = min(t0, t1);
    vec3 tmx = max(t0, t1);
    float tn = max(max(tmn.x, tmn.y), tmn.z);
    float tf = min(min(tmx.x, tmx.y), tmx.z);
    return vec2(max(tn, 0.0), tf);
}

vec2 slabHit(float oy, float dy, float y0, float y1) {
    if (abs(dy) < 0.00001) {
        if (oy > y0 && oy < y1) {
            return vec2(0.0, 1.0e9);
        }
        return vec2(1.0, 0.0);
    }
    float ta = (y0 - oy) / dy;
    float tb = (y1 - oy) / dy;
    return vec2(max(min(ta, tb), 0.0), max(ta, tb));
}

float gradNoise(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

vec3 flashLight(vec3 p) {
    vec4 f[4];
    f[0] = Flash0;
    f[1] = Flash1;
    f[2] = Flash2;
    f[3] = Flash3;
    float b = 0.0;
    for (int i = 0; i < 4; i++) {
        if (f[i].w > 0.001) {
            vec3 dv = p - f[i].xyz;
            b += f[i].w / (1.0 + 3.0 * dot(dv, dv) / 270000.0);
        }
    }
    return vec3(0.55, 0.65, 1.0) * min(b, 1.2) * Params.z;
}

float totalDensity(vec3 p, int lod, Storm s0, Storm s1) {
    float d = 0.0;
    if (Weather.w > 0.5 && p.y > Layers.z && p.y < Layers.x + Layers.y) {
        d = ambientDensity(vec3(p.x + CamPos.x, p.y, p.z + CamPos.z), lod);
    }
    float a = stormDensity(s0, p, lod);
    float b = stormDensity(s1, p, lod);
    return 1.0 - (1.0 - d) * (1.0 - a) * (1.0 - b);
}

vec3 funnelPass(Storm s, vec3 ro, vec3 rd, float tT, float jit, inout float trans) {
    vec3 col = vec3(0.0);
    float len = s.f.x;
    if (s.d.w < 0.5 || len < 0.01 || s.f.w < 0.001) {
        return col;
    }
    float gy = s.e.z;
    float topY = s.e.w;
    float fullH = topY - gy;
    if (fullH < 20.0) {
        return col;
    }
    vec2 tc = s.a.xy + s.e.xy;
    float rg = s.f.z * 1.8;
    float shiftLen = 0.22 * fullH;
    vec2 mid = tc + s.c.xy * shiftLen * 0.5;
    float hw = 110.0 + rg * 3.0 + shiftLen;
    vec3 lo = vec3(mid.x - hw, gy - 5.0, mid.y - hw);
    vec3 hi = vec3(mid.x + hw, topY + 5.0, mid.y + hw);
    vec2 hit = boxHit(ro, rd, lo, hi);
    float t0 = hit.x;
    float t1 = min(hit.y, tT);
    if (t1 <= t0) {
        return col;
    }
    const int M = 36;
    float ds = (t1 - t0) / float(M);
    for (int k = 0; k < M; k++) {
        float t = t0 + ds * (float(k) + jit);
        vec3 p = ro + rd * t;
        vec2 fd = funnelDensity(s, p);
        float dtot = fd.x + fd.y;
        if (dtot > 0.002) {
            float dustFrac = fd.y / max(dtot, 0.0001);
            vec3 lit = AmbCol.rgb * 0.50 + SunCol.rgb * SunDir.w * 0.14;
            lit *= 0.80;
            vec3 dustLit = vec3(0.50, 0.43, 0.36) * (0.28 + 0.38 * SunCol.a);
            lit = mix(lit, dustLit, dustFrac);
            lit += flashLight(p) * 0.6;
            float a = 1.0 - exp(-dtot * ds * 0.06);
            col += trans * a * lit;
            trans *= 1.0 - a;
        }
        if (trans < 0.02) {
            break;
        }
    }
    return col;
}

void main() {
    vec2 uv = ndc * 0.5 + 0.5;
    float depth = texture(Sampler1, uv).r;
    vec4 fp = InvViewProj * vec4(ndc, 1.0, 1.0);
    vec3 rd = normalize(fp.xyz / fp.w);
    float tT = 1.0e9;
    if (depth < 0.99999) {
        vec4 wp = InvViewProj * vec4(ndc, depth * 2.0 - 1.0, 1.0);
        tT = length(wp.xyz / wp.w);
    }
    vec3 ro = vec3(0.0, CamPos.y, 0.0);
    float jit = gradNoise(gl_FragCoord.xy);

    Storm s0 = Storm(StormA0, StormB0, StormC0, StormD0, StormE0, StormF0, StormG0);
    Storm s1 = Storm(StormA1, StormB1, StormC1, StormD1, StormE1, StormF1, StormG1);

    vec3 col = vec3(0.0);
    float trans = 1.0;

    // ---- tornado funnels first (they are the closest thing)
    col += funnelPass(s0, ro, rd, tT, jit, trans);
    col += funnelPass(s1, ro, rd, tT, jit, trans);

    // ---- cloud ray interval
    float tStart = 1.0e9;
    float tEnd = 0.0;
    if (Weather.w > 0.5) {
        vec2 h = slabHit(ro.y, rd.y, Layers.z, Layers.x + Layers.y);
        if (h.y > h.x) {
            tStart = min(tStart, h.x);
            tEnd = max(tEnd, h.y);
        }
    }
    for (int si = 0; si < 2; si++) {
        Storm s = si == 0 ? s0 : s1;
        if (s.d.w > 0.5 && s.b.x > 0.02) {
            float ext = max(s.c.w * s.b.y * 1.2, s.a.w * 2.2);
            vec3 lo = vec3(s.a.x - ext, s.a.z - s.d.z - 100.0, s.a.y - ext);
            vec3 hi = vec3(s.a.x + ext, s.a.z + s.c.z + 150.0, s.a.y + ext);
            vec2 h = boxHit(ro, rd, lo, hi);
            if (h.y > h.x) {
                tStart = min(tStart, h.x);
                tEnd = max(tEnd, h.y);
            }
        }
    }
    tEnd = min(tEnd, min(tT, Params.y));

    vec3 S = normalize(SunDir.xyz);
    float cosang = dot(rd, S);
    float hg1 = (1.0 - 0.3025) / pow(1.3025 - 1.1 * cosang, 1.5) / 12.566371;
    float hg2 = (1.0 - 0.0625) / pow(1.0625 + 0.5 * cosang, 1.5) / 12.566371;
    float phase = mix(hg1, hg2, 0.3) * 3.14159 + 0.45;

    if (tEnd > tStart && trans > 0.02) {
        float t = max(tStart, 1.0);
        int maxSteps = int(Params.x);
        for (int i = 0; i < 160; i++) {
            if (i >= maxSteps || t > tEnd || trans < 0.02) {
                break;
            }
            float step = clamp(0.04 * t, 12.0, 90.0);
            vec3 p = ro + rd * (t + step * jit);
            float d = totalDensity(p, 0, s0, s1);
            if (d > 0.002) {
                float tau = 0.0;
                tau += totalDensity(p + S * 30.0, 1, s0, s1) * 30.0 * 0.020;
                tau += totalDensity(p + S * 70.0, 1, s0, s1) * 70.0 * 0.020;
                tau += totalDensity(p + S * 150.0, 1, s0, s1) * 150.0 * 0.020;
                float sunT = max(exp(-tau), 0.45 * exp(-tau * 0.20));
                float hgt = clamp((p.y - Layers.x) / 300.0, 0.0, 1.0);
                vec3 direct = SunCol.rgb * (SunDir.w * sunT * phase) * 1.15;
                vec3 amb = AmbCol.rgb * (0.30 + 0.45 * hgt);
                vec3 lit = direct + amb;
                // storms make the cloud darker, mostly at the bottom
                float near = 1.0 - sm(0.2 * s0.c.w + 1.0, 1.1 * s0.c.w + 2.0, length(vec2(p.x - s0.a.x, p.z - s0.a.y)));
                near *= s0.d.w;
                lit *= 1.0 - 0.55 * near * (1.0 - hgt);
                lit += flashLight(p);
                float hz = 1.0 - exp(-(t + step * jit) / 9000.0);
                lit = mix(lit, HorCol.rgb * 0.9, hz);
                float a = 1.0 - exp(-d * step * 0.030);
                col += trans * a * lit;
                trans *= 1.0 - a;
                t += step;
            } else {
                t += step * 1.6;
            }
        }
    }

    // ---- cloud shadows on the terrain
    if (Params.w > 0.5 && tT < 3000.0 && SunDir.y > 0.08) {
        vec3 P = ro + rd * tT;
        float yTop = max(Layers.x + Layers.y, max(s0.a.z + s0.c.z + 100.0, s1.a.z + s1.c.z + 100.0));
        float dmax = min((yTop - P.y) / S.y, 6000.0);
        if (dmax > 10.0) {
            float tau = 0.0;
            float sd = dmax / 9.0;
            for (int k = 0; k < 9; k++) {
                vec3 q = P + S * (sd * (float(k) + jit));
                tau += totalDensity(q, 1, s0, s1) * sd * 0.015;
            }
            float shadow = (1.0 - exp(-tau)) * HorCol.a * smoothstep(0.08, 0.30, SunDir.y);
            trans *= 1.0 - shadow;
        }
    }

    fragColor = vec4(col, 1.0 - trans);
}

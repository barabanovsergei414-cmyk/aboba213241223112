package com.realweather.net;

import com.realweather.RealWeather;
import com.realweather.storm.StormData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.ArrayList;
import java.util.List;

/** Server -> client: all storms of the dimension plus the world seed (used for wind and ambient clouds). */
public record StormSyncPayload(long worldSeed, List<StormData> storms) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<StormSyncPayload> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(RealWeather.MODID, "storm_sync"));

    public static final StreamCodec<FriendlyByteBuf, StormSyncPayload> CODEC =
            StreamCodec.of(StormSyncPayload::write, StormSyncPayload::read);

    private static void write(FriendlyByteBuf buf, StormSyncPayload p) {
        buf.writeLong(p.worldSeed);
        buf.writeVarInt(p.storms.size());
        for (StormData s : p.storms) {
            s.write(buf);
        }
    }

    private static StormSyncPayload read(FriendlyByteBuf buf) {
        long seed = buf.readLong();
        int n = buf.readVarInt();
        List<StormData> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(StormData.read(buf));
        }
        return new StormSyncPayload(seed, list);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}

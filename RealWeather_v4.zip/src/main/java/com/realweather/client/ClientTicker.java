package com.realweather.client;

import com.realweather.ClientConfig;
import com.realweather.storm.StormData;
import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.Iterator;
import java.util.Random;

/** Everything that runs once per client tick. */
public final class ClientTicker {
    private static final double[] rc = new double[2];
    private static final double[] tp = new double[2];
    private static final Random RND = new Random();
    private static boolean appliedVanilla = false;
    private static boolean cloudsOverridden = false;
    private static CloudStatus savedCloudStatus = CloudStatus.FANCY;

    private ClientTicker() {}

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null) return;
        if (level.dimension() != Level.OVERWORLD) {
            restoreClouds(mc);
            return;
        }
        ClientState.tick++;

        Iterator<StormData> it = ClientState.storms.iterator();
        while (it.hasNext()) {
            StormData s = it.next();
            s.tick();
            if (s.age >= s.life) {
                it.remove();
            }
        }

        AmbientClouds.update(level);
        environment(player);
        applyVanilla(level);
        LightningRenderer.tick();
        debris(level, player);
        ClientAudio.tick(mc);
        handleVanillaClouds(mc);
    }

    private static void environment(LocalPlayer player) {
        double px = player.getX(), pz = player.getZ();
        float skyT = 0f, rainT = 0f, windT = 0f;
        for (StormData s : ClientState.storms) {
            float a = s.age;
            float g1 = s.tower(a), g2 = s.anvil(a), g3 = s.mature(a), dis = s.dissipate(a);
            double dx = px - s.x, dz = pz - s.z;
            float d = (float) Math.sqrt(dx * dx + dz * dz);
            float reach = s.towerRadius() * 1.8f * g1 + s.anvilRadius() * 0.7f * g2;
            float dark = (1f - SkyModel.smoothstep(0.25f * reach, Math.max(1f, reach), d)) * (0.35f * g1 + 0.65f * g2) * (1f - dis);
            if (s.kind == StormData.KIND_DRY) dark *= 0.6f;
            skyT = Math.max(skyT, dark);

            s.rainCenter(rc);
            double rx = px - rc[0], rz = pz - rc[1];
            float dr = (float) Math.sqrt(rx * rx + rz * rz);
            float Rp = s.rainRadius() * (0.55f + 0.45f * g3);
            float rain = (1f - SkyModel.smoothstep(0.45f * Rp, 1.05f * Rp, dr)) * g3 * s.rainAmount() * (1f - dis);
            rainT = Math.max(rainT, rain);

            float w = (1f - SkyModel.smoothstep(0.3f * reach, Math.max(1f, 1.3f * reach), d)) * g1 * (1f - dis);
            windT = Math.max(windT, w);
        }
        ClientState.skyStorm += (skyT - ClientState.skyStorm) * 0.05f;
        ClientState.rain += (rainT - ClientState.rain) * 0.06f;
        ClientState.wind += (windT - ClientState.wind) * 0.05f;
        float over = AmbientClouds.moodOver * (1f - ClientState.skyStorm);
        ClientState.overcast += (over - ClientState.overcast) * 0.01f;
        ClientState.cirrus = AmbientClouds.cirrusAmt;
    }

    private static void applyVanilla(ClientLevel level) {
        float rain = Math.min(1f, ClientState.rain);
        float dark = ClientConfig.STORM_DARKNESS.get().floatValue();
        float thunder = Math.min(1f, Math.max(rain, ClientState.skyStorm * 0.75f)) * dark;
        boolean active = rain > 0.002f || thunder > 0.002f;
        if (active || appliedVanilla) {
            level.setRainLevel(rain);
            level.setThunderLevel(thunder);
            appliedVanilla = active;
        }
    }

    private static void debris(ClientLevel level, LocalPlayer player) {
        if (!ClientConfig.DEBRIS_PARTICLES.get()) return;
        for (StormData s : ClientState.storms) {
            if (!s.hasTornado() || !s.touching(s.age)) continue;
            s.tornadoPos(s.age, tp);
            double dx = tp[0] - player.getX(), dz = tp[1] - player.getZ();
            if (dx * dx + dz * dz > 280.0 * 280.0) continue;
            int bx = (int) Math.floor(tp[0]), bz = (int) Math.floor(tp[1]);
            if (!level.hasChunk(bx >> 4, bz >> 4)) continue;
            float rg = s.groundRadius(s.age);
            for (int i = 0; i < 5; i++) {
                double ang = RND.nextDouble() * Math.PI * 2;
                double rad = rg * (0.4 + RND.nextDouble() * 1.4);
                double x = tp[0] + Math.cos(ang) * rad, z = tp[1] + Math.sin(ang) * rad;
                int y = level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(x), (int) Math.floor(z));
                BlockState st = level.getBlockState(new BlockPos((int) Math.floor(x), y - 1, (int) Math.floor(z)));
                if (st.isAir()) continue;
                double tx = -Math.sin(ang), tz = Math.cos(ang);
                level.addParticle(new BlockParticleOption(ParticleTypes.BLOCK, st), x, y + 0.3, z,
                        tx * 0.5 + (RND.nextDouble() - 0.5) * 0.2, 0.35 + RND.nextDouble() * 0.5, tz * 0.5 + (RND.nextDouble() - 0.5) * 0.2);
            }
        }
    }

    private static void handleVanillaClouds(Minecraft mc) {
        if (ClientConfig.CLOUDS.get()) {
            if (!cloudsOverridden) {
                savedCloudStatus = mc.options.cloudStatus().get();
                cloudsOverridden = true;
            }
            if (mc.options.cloudStatus().get() != CloudStatus.OFF) {
                mc.options.cloudStatus().set(CloudStatus.OFF);
            }
        } else {
            restoreClouds(mc);
        }
    }

    public static void restoreClouds(Minecraft mc) {
        if (cloudsOverridden) {
            mc.options.cloudStatus().set(savedCloudStatus);
            cloudsOverridden = false;
        }
    }

    public static void onLogout() {
        restoreClouds(Minecraft.getInstance());
        ClientState.reset();
        ClientAudio.reset();
        TornadoRenderer.clearCache();
        RainShaftRenderer.clearCache();
        ShadowRenderer.clearCache();
        appliedVanilla = false;
    }
}

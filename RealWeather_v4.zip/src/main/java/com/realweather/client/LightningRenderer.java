package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.realweather.ClientConfig;
import com.realweather.RWSounds;
import com.realweather.net.FlashPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/** Lightning: branched bolts, in-cloud flashes, glow that lights the clouds, delayed thunder. */
public final class LightningRenderer {

    /** One bolt segment. */
    private static final class Seg {
        float x1, y1, z1, x2, y2, z2, width, power;
    }

    public static final class Flash {
        float x, gy, z, cy;
        int kind;
        long start;
        int duration;
        float strength;
        float radius;
        float[] pulseAt = new float[3];
        float[] pulseAmp = new float[3];
        List<Seg> segs = new ArrayList<>();
    }

    public static final class Thunder {
        long at;
        double x, y, z;
        float dist;
        int kind;
    }

    private static final Random RND = new Random();
    private static final float SOUND_SPEED = 17.15f; // blocks per tick (343 m/s)

    private LightningRenderer() {}

    // ------------------------------------------------------------------ creation
    public static void addFlash(FlashPayload p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Flash f = new Flash();
        f.x = p.x();
        f.gy = p.groundY();
        f.z = p.z();
        f.cy = p.cloudY();
        f.kind = p.kind();
        f.start = ClientState.tick;
        Random r = new Random(p.seed());
        switch (f.kind) {
            case FlashPayload.IC:
                f.duration = 14;
                f.strength = 0.9f;
                f.radius = 520f;
                break;
            case FlashPayload.SHEET:
                f.duration = 18;
                f.strength = 0.7f;
                f.radius = 900f;
                break;
            case FlashPayload.CC:
                f.duration = 16;
                f.strength = 0.8f;
                f.radius = 600f;
                break;
            default:
                f.duration = 12;
                f.strength = 1.1f;
                f.radius = 380f;
                break;
        }
        int pulses = 2 + r.nextInt(2);
        for (int i = 0; i < 3; i++) {
            f.pulseAt[i] = i == 0 ? 0f : f.pulseAt[i - 1] + 1.5f + r.nextFloat() * 3f;
            f.pulseAmp[i] = i < pulses ? (i == 0 ? 1f : 0.45f + 0.5f * r.nextFloat()) : 0f;
        }
        if (f.kind == FlashPayload.CG) {
            bolt(f, r, f.x, f.cy, f.z, f.x, f.gy, f.z, 1f);
        } else if (f.kind == FlashPayload.IC) {
            crawler(f, r, f.x, f.cy, f.z, 0f, 0f, 260f, 0.7f, 3);
        } else if (f.kind == FlashPayload.CC) {
            crawler(f, r, f.x, f.cy, f.z, p.dirX(), p.dirZ(), Math.max(150f, p.length()), 0.9f, 4);
        }
        if (ClientConfig.LIGHTNING_VISUALS.get()) {
            ClientState.flashes.add(f);
        }

        // thunder arrives later
        double dx = f.x - mc.player.getX(), dz = f.z - mc.player.getZ();
        double dy = (f.kind == FlashPayload.CG ? f.gy : f.cy) - mc.player.getY();
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (f.kind != FlashPayload.CG_REAL && f.kind != FlashPayload.SHEET || dist > 500f) {
            Thunder t = new Thunder();
            t.at = ClientState.tick + (long) (dist / SOUND_SPEED);
            t.x = f.x;
            t.y = (f.kind == FlashPayload.CG ? f.gy : f.cy);
            t.z = f.z;
            t.dist = dist;
            t.kind = f.kind;
            ClientState.thunders.add(t);
        }
    }

    /** Jagged main channel from (x1,y1,z1) to (x2,y2,z2) with branches. */
    private static void bolt(Flash f, Random r, float x1, float y1, float z1, float x2, float y2, float z2, float power) {
        int n = 22;
        float[] px = new float[n + 1], py = new float[n + 1], pz = new float[n + 1];
        float jx = 0f, jz = 0f;
        float len = Math.abs(y1 - y2);
        float amp = Math.max(6f, len * 0.05f);
        for (int i = 0; i <= n; i++) {
            float t = i / (float) n;
            jx += (r.nextFloat() - 0.5f) * amp;
            jz += (r.nextFloat() - 0.5f) * amp;
            jx *= 0.82f;
            jz *= 0.82f;
            float fix = (float) Math.sin(Math.PI * t) * 1.0f;
            px[i] = x1 + (x2 - x1) * t + jx * fix;
            py[i] = y1 + (y2 - y1) * t;
            pz[i] = z1 + (z2 - z1) * t + jz * fix;
        }
        float baseW = Math.max(0.5f, len * 0.004f);
        for (int i = 0; i < n; i++) {
            seg(f, px[i], py[i], pz[i], px[i + 1], py[i + 1], pz[i + 1], baseW * (1.2f - 0.5f * i / n), power);
            if (i > 3 && i < n - 2 && r.nextFloat() < 0.22f) {
                branch(f, r, px[i], py[i], pz[i], power * 0.55f, baseW * 0.6f, len * 0.35f, 2);
            }
        }
    }

    private static void branch(Flash f, Random r, float x, float y, float z, float power, float width, float length, int depth) {
        int n = 7;
        float ang = r.nextFloat() * 6.2831855f;
        float dirX = (float) Math.cos(ang), dirZ = (float) Math.sin(ang);
        float step = length / n;
        float cx = x, cy = y, cz = z;
        for (int i = 0; i < n; i++) {
            float nx = cx + dirX * step * (0.6f + r.nextFloat() * 0.6f) + (r.nextFloat() - 0.5f) * step * 0.5f;
            float ny = cy - step * (0.55f + r.nextFloat() * 0.5f);
            float nz = cz + dirZ * step * (0.6f + r.nextFloat() * 0.6f) + (r.nextFloat() - 0.5f) * step * 0.5f;
            seg(f, cx, cy, cz, nx, ny, nz, width * (1f - 0.7f * i / n), power);
            if (depth > 0 && i > 1 && r.nextFloat() < 0.18f) {
                branch(f, r, nx, ny, nz, power * 0.6f, width * 0.6f, length * 0.5f, depth - 1);
            }
            cx = nx;
            cy = ny;
            cz = nz;
        }
    }

    /** Branching horizontal discharge inside / under the cloud. */
    private static void crawler(Flash f, Random r, float x, float y, float z, float dx, float dz, float length, float power, int branches) {
        float cx = x, cy = y, cz = z;
        float ang = (dx == 0f && dz == 0f) ? r.nextFloat() * 6.2831855f : (float) Math.atan2(dz, dx);
        int n = 16;
        float step = length / n;
        for (int i = 0; i < n; i++) {
            ang += (r.nextFloat() - 0.5f) * 0.6f;
            float nx = cx + (float) Math.cos(ang) * step;
            float nz = cz + (float) Math.sin(ang) * step;
            float ny = cy + (r.nextFloat() - 0.5f) * step * 0.35f;
            seg(f, cx, cy, cz, nx, ny, nz, 1.6f + length * 0.004f, power);
            if (i > 1 && r.nextFloat() < 0.35f && branches > 0) {
                float bx = nx, by = ny, bz = nz;
                float ba = ang + (r.nextBoolean() ? 1f : -1f) * (0.6f + r.nextFloat());
                for (int k = 0; k < 6; k++) {
                    ba += (r.nextFloat() - 0.5f) * 0.7f;
                    float ex = bx + (float) Math.cos(ba) * step * 0.7f;
                    float ez = bz + (float) Math.sin(ba) * step * 0.7f;
                    float ey = by + (r.nextFloat() - 0.5f) * step * 0.3f;
                    seg(f, bx, by, bz, ex, ey, ez, 1.0f, power * 0.6f);
                    bx = ex;
                    by = ey;
                    bz = ez;
                }
            }
            cx = nx;
            cy = ny;
            cz = nz;
        }
    }

    private static void seg(Flash f, float x1, float y1, float z1, float x2, float y2, float z2, float w, float power) {
        Seg s = new Seg();
        s.x1 = x1;
        s.y1 = y1;
        s.z1 = z1;
        s.x2 = x2;
        s.y2 = y2;
        s.z2 = z2;
        s.width = w;
        s.power = power;
        f.segs.add(s);
    }

    // ------------------------------------------------------------------ brightness
    private static float envelope(Flash f, float ageTicks) {
        float e = 0f;
        for (int i = 0; i < 3; i++) {
            float dt = ageTicks - f.pulseAt[i];
            if (dt < 0f || f.pulseAmp[i] <= 0f) continue;
            float v = f.pulseAmp[i] * (float) Math.exp(-dt * 0.55f) * Math.min(1f, dt * 2.5f + 0.35f);
            if (v > e) e = v;
        }
        float tail = Math.max(0f, 1f - ageTicks / f.duration) * 0.22f;
        return Math.min(1f, e + tail * (e > 0f ? 1f : 0f));
    }

    /** Current brightness of a flash (0..~1.2), used by the volumetric cloud shader. */
    public static float level(Flash f, float now) {
        float age = now - f.start;
        if (age < 0f || age > f.duration) return 0f;
        return envelope(f, age) * f.strength;
    }

    /** Extra light for a point in the sky (used to light up clouds). */
    public static float boost(double wx, double wy, double wz) {
        if (ClientState.flashes.isEmpty()) return 0f;
        float k = ClientConfig.FLASH_BRIGHTNESS.get().floatValue();
        if (k <= 0f) return 0f;
        float total = 0f;
        float now = ClientState.tick + Frame.partial;
        for (Flash f : ClientState.flashes) {
            float age = now - f.start;
            if (age < 0f || age > f.duration) continue;
            float e = envelope(f, age);
            if (e <= 0.01f) continue;
            double ly = (f.kind == FlashPayload.CG || f.kind == FlashPayload.CG_REAL) ? f.cy : f.cy;
            double dx = wx - f.x, dy = wy - ly, dz = wz - f.z;
            float d2 = (float) (dx * dx + dy * dy * 0.6 + dz * dz);
            float rr = f.radius * f.radius;
            total += e * f.strength / (1f + 3f * d2 / rr);
        }
        return Math.min(1.2f, total * 0.8f * k);
    }

    // ------------------------------------------------------------------ per tick
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        long now = ClientState.tick;
        Iterator<Flash> it = ClientState.flashes.iterator();
        float sky = 0f, screen = 0f;
        while (it.hasNext()) {
            Flash f = it.next();
            float age = now - f.start;
            if (age > f.duration + 2) {
                it.remove();
                continue;
            }
            if (mc.player != null) {
                float e = envelope(f, age);
                double dx = f.x - mc.player.getX(), dz = f.z - mc.player.getZ();
                float d = (float) Math.sqrt(dx * dx + dz * dz);
                sky = Math.max(sky, e * f.strength * (1f / (1f + d * d / (1400f * 1400f) * 2f)));
                screen = Math.max(screen, e * (1f - SkyModel.smoothstep(120f, 900f, d)) * (f.kind == FlashPayload.CG || f.kind == FlashPayload.CG_REAL ? 1f : 0.5f));
            }
        }
        float fb = ClientConfig.FLASH_BRIGHTNESS.get().floatValue();
        ClientState.skyFlash = Math.min(1f, sky * 0.55f * fb);
        ClientState.screenFlash = Math.min(0.55f, screen * 0.35f * fb);

        // thunder
        Iterator<Thunder> ti = ClientState.thunders.iterator();
        float vol = ClientConfig.THUNDER_VOLUME.get().floatValue();
        while (ti.hasNext()) {
            Thunder t = ti.next();
            if (now < t.at) continue;
            ti.remove();
            if (level == null || vol <= 0f) continue;
            playThunder(level, t, vol);
        }
    }

    private static void playThunder(ClientLevel level, Thunder t, float vol) {
        SoundEvent ev;
        float pitch = 0.85f + RND.nextFloat() * 0.2f;
        if (t.dist < 350f) {
            ev = RND.nextBoolean() ? RWSounds.THUNDER_NEAR.get() : RWSounds.THUNDER_MID.get();
        } else if (t.dist < 1200f) {
            ev = RND.nextBoolean() ? RWSounds.THUNDER_ROLL.get() : RWSounds.THUNDER_MID.get();
        } else {
            ev = RWSounds.THUNDER_FAR.get();
            pitch = 0.80f + RND.nextFloat() * 0.15f;
        }
        float v = Math.max(3f, t.dist / 10f + 3f) * vol;
        level.playLocalSound(t.x, t.y, t.z, ev, SoundSource.WEATHER, v, pitch, false);
    }

    // ------------------------------------------------------------------ draw
    public static void draw() {
        if (ClientState.flashes.isEmpty() || !ClientConfig.LIGHTNING_VISUALS.get()) return;
        float now = ClientState.tick + Frame.partial;
        float fb = ClientConfig.FLASH_BRIGHTNESS.get().floatValue();
        Gfx.texState(Gfx.BOLT, true, false, true);
        BufferBuilder bb = Gfx.beginTexColor();
        boolean any = false;
        for (Flash f : ClientState.flashes) {
            if (f.segs.isEmpty()) continue;
            float age = now - f.start;
            if (age < 0f || age > f.duration) continue;
            float e = envelope(f, age) * fb;
            if (e <= 0.02f) continue;
            for (Seg s : f.segs) {
                any |= quad(bb, s, e, 1);
            }
        }
        if (any) {
            Gfx.flush(bb);
        }
        Gfx.resetState();
    }

    private static boolean quad(BufferBuilder bb, Seg s, float e, int glowPass) {
        float ax = (float) (s.x1 - Frame.cx), ay = (float) (s.y1 - Frame.cy), az = (float) (s.z1 - Frame.cz);
        float bx = (float) (s.x2 - Frame.cx), by = (float) (s.y2 - Frame.cy), bz = (float) (s.z2 - Frame.cz);
        float mx = (ax + bx) * 0.5f, my = (ay + by) * 0.5f, mz = (az + bz) * 0.5f;
        float dist = (float) Math.sqrt(mx * mx + my * my + mz * mz);
        float k = dist > Frame.maxD ? Frame.maxD / dist : 1f;
        ax *= k; ay *= k; az *= k; bx *= k; by *= k; bz *= k;
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float cxv = -(ax + bx) * 0.5f, cyv = -(ay + by) * 0.5f, czv = -(az + bz) * 0.5f;
        // side = dir x toCamera
        float sx = dy * czv - dz * cyv;
        float sy = dz * cxv - dx * czv;
        float sz = dx * cyv - dy * cxv;
        float sl = (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        if (sl < 1e-5f) return false;
        sx /= sl; sy /= sl; sz /= sl;
        float far = Math.max(1f, dist / 220f);
        float glowW = (s.width * 7f + 2f) * far * k;
        float coreW = Math.max(s.width * 0.9f, 0.35f) * far * k;
        float p = s.power * e;
        // glow (blue-violet)
        addStrip(bb, ax, ay, az, bx, by, bz, sx, sy, sz, glowW, 0.45f, 0.55f, 1.0f, 0.55f * p);
        // core (white)
        addStrip(bb, ax, ay, az, bx, by, bz, sx, sy, sz, coreW, 1.0f, 1.0f, 1.0f, Math.min(1f, 1.1f * p));
        return true;
    }

    private static void addStrip(BufferBuilder bb, float ax, float ay, float az, float bx, float by, float bz,
                                 float sx, float sy, float sz, float w, float r, float g, float b, float a) {
        Gfx.vert(bb, ax - sx * w, ay - sy * w, az - sz * w, 0f, 0f, r, g, b, a);
        Gfx.vert(bb, ax + sx * w, ay + sy * w, az + sz * w, 0f, 1f, r, g, b, a);
        Gfx.vert(bb, bx + sx * w, by + sy * w, bz + sz * w, 1f, 1f, r, g, b, a);
        Gfx.vert(bb, bx - sx * w, by - sy * w, bz - sz * w, 1f, 0f, r, g, b, a);
    }
}

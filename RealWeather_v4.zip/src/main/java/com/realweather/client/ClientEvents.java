package com.realweather.client;

import com.realweather.ClientConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.material.FogType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;

public final class ClientEvents {
    private static final float[] fog = new float[3];

    private ClientEvents() {}

    public static void register(IEventBus bus) {
        bus.addListener(ClientEvents::onClientTick);
        bus.addListener(ClientEvents::onRenderLevel);
        bus.addListener(ClientEvents::onFogColor);
        bus.addListener(ClientEvents::onRenderFog);
        bus.addListener(ClientEvents::onGui);
        bus.addListener(ClientEvents::onLogout);
    }

    private static void onClientTick(ClientTickEvent.Post event) {
        ClientTicker.tick();
    }

    private static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientTicker.onLogout();
    }

    private static void onRenderLevel(RenderLevelStageEvent event) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || level.dimension() != Level.OVERWORLD) return;
        RenderLevelStageEvent.Stage stage = event.getStage();
        if (stage == RenderLevelStageEvent.Stage.AFTER_SKY) {
            if (!ClientConfig.SKY.get()) return;
            if (event.getCamera().getFluidInCamera() != FogType.NONE) return;
            float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            Frame.setup(level, event.getCamera(), partial, event.getModelViewMatrix());
            AmbientClouds.update(level);
            SkyRenderer.draw();
        } else if (stage == RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) {
            if (!ClientConfig.CLOUDS.get()) return;
            if (event.getCamera().getFluidInCamera() != FogType.NONE) return;
            float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
            Frame.setup(level, event.getCamera(), partial, event.getModelViewMatrix());
            WeatherRenderer.render(event.getProjectionMatrix());
        }
    }

    private static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (!ClientConfig.SKY.get()) return;
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || mc.player == null || level.dimension() != Level.OVERWORLD) return;
        if (event.getCamera().getFluidInCamera() != FogType.NONE) return;
        if (mc.player.hasEffect(MobEffects.BLINDNESS) || mc.player.hasEffect(MobEffects.DARKNESS)) return;
        float sunY = SkyModel.sunY(level, (float) event.getPartialTick());
        SkyModel.horizon(sunY, ClientState.skyStorm, ClientState.overcast, fog);
        event.setRed(fog[0]);
        event.setGreen(fog[1]);
        event.setBlue(fog[2]);
    }

    private static void onRenderFog(ViewportEvent.RenderFog event) {
        if (!ClientConfig.STORM_FOG.get()) return;
        if (event.getMode() != FogRenderer.FogMode.FOG_TERRAIN || event.getType() != FogType.NONE) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.level.dimension() != Level.OVERWORLD) return;
        float f = Math.max(ClientState.rain * 0.9f, ClientState.skyStorm * 0.30f);
        if (f < 0.04f) return;
        float far = event.getFarPlaneDistance();
        float newFar = Math.max(70f, far * (1f - 0.80f * f));
        if (newFar >= far) return;
        event.setNearPlaneDistance(newFar * 0.08f);
        event.setFarPlaneDistance(newFar);
        event.setCanceled(true);
    }

    private static void onGui(RenderGuiEvent.Pre event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || mc.level.dimension() != Level.OVERWORLD) return;
        int w = event.getGuiGraphics().guiWidth();
        int h = event.getGuiGraphics().guiHeight();
        float dark = ClientState.skyStorm * ClientConfig.STORM_DARKNESS.get().floatValue();
        if (dark > 0.03f) {
            int a = (int) (Math.min(0.28f, dark * 0.26f) * 255f);
            event.getGuiGraphics().fill(0, 0, w, h, (a << 24) | 0x0E1A16);
        }
        float fl = ClientState.screenFlash;
        if (fl > 0.02f) {
            int a = (int) (Math.min(0.55f, fl) * 255f);
            event.getGuiGraphics().fill(0, 0, w, h, (a << 24) | 0xDCE6FF);
        }
    }
}

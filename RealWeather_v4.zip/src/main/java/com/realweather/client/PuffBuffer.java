package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;

import java.util.Arrays;

/** Collects camera-facing puffs of a frame, sorts them back to front and draws them. */
public final class PuffBuffer {
    private static final int MAX = 24000;
    private static final float[] px = new float[MAX], py = new float[MAX], pz = new float[MAX];
    private static final float[] ps = new float[MAX], pf = new float[MAX], prot = new float[MAX];
    private static final float[] cr = new float[MAX], cg = new float[MAX], cb = new float[MAX], ca = new float[MAX];
    private static final byte[] pv = new byte[MAX];
    private static final long[] keys = new long[MAX];
    public static int n;

    private PuffBuffer() {}

    public static void clear() {
        n = 0;
    }

    /**
     * Add a puff at a world position. Anything beyond Frame.maxD is pulled in to that distance (and shrunk by the same
     * factor) so it stays inside the projection; the picture on screen is identical.
     */
    public static void add(double wx, double wy, double wz, float size, float flat,
                           float r, float g, float b, float a, float rot, int variant) {
        if (n >= MAX || a <= 0.004f || size <= 0.5f) return;
        float dx = (float) (wx - Frame.cx);
        float dy = (float) (wy - Frame.cy);
        float dz = (float) (wz - Frame.cz);
        float dist = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float k = 1f;
        if (dist > Frame.maxD) {
            k = Frame.maxD / dist;
        }
        float rdx = dx * k, rdy = dy * k, rdz = dz * k;
        float s = size * k;
        float dot = rdx * Frame.lx + rdy * Frame.ly + rdz * Frame.lz;
        if (dot < -s * 0.8f) return;
        float dk = dist * k;
        if (dk < s * 0.7f) {
            a *= SkyModel.smoothstep(s * 0.10f, s * 0.70f, dk);
            if (a <= 0.004f) return;
        }
        px[n] = rdx;
        py[n] = rdy;
        pz[n] = rdz;
        ps[n] = s;
        pf[n] = flat;
        prot[n] = rot;
        cr[n] = r;
        cg[n] = g;
        cb[n] = b;
        ca[n] = a;
        pv[n] = (byte) variant;
        keys[n] = ((long) Float.floatToIntBits(dist) << 32) | n;
        n++;
    }

    public static void draw() {
        if (n == 0) return;
        Arrays.sort(keys, 0, n);
        Gfx.texState(Gfx.PUFF, false, false, true);
        BufferBuilder bb = Gfx.beginTexColor();
        float rX = Frame.rx, rY = Frame.ry, rZ = Frame.rz;
        float uX = Frame.ux, uY = Frame.uy, uZ = Frame.uz;
        for (int q = n - 1; q >= 0; q--) {
            int i = (int) (keys[q] & 0xFFFFFFFFL);
            float c = (float) Math.cos(prot[i]);
            float s = (float) Math.sin(prot[i]);
            float h = ps[i];
            float ax = (rX * c + uX * s) * h;
            float ay = (rY * c + uY * s) * h * pf[i];
            float az = (rZ * c + uZ * s) * h;
            float bx = (-rX * s + uX * c) * h;
            float by = (-rY * s + uY * c) * h * pf[i];
            float bz = (-rZ * s + uZ * c) * h;
            int v = pv[i];
            float u0 = (v & 1) * 0.5f;
            float v0 = ((v >> 1) & 1) * 0.5f;
            float x = px[i], y = py[i], z = pz[i];
            float r = cr[i], g = cg[i], b = cb[i], a = ca[i];
            Gfx.vert(bb, x - ax - bx, y - ay - by, z - az - bz, u0, v0 + 0.5f, r, g, b, a);
            Gfx.vert(bb, x + ax - bx, y + ay - by, z + az - bz, u0 + 0.5f, v0 + 0.5f, r, g, b, a);
            Gfx.vert(bb, x + ax + bx, y + ay + by, z + az + bz, u0 + 0.5f, v0, r, g, b, a);
            Gfx.vert(bb, x - ax + bx, y - ay + by, z - az + bz, u0, v0, r, g, b, a);
        }
        Gfx.flush(bb);
        Gfx.resetState();
    }
}

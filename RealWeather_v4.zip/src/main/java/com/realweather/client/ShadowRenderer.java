package com.realweather.client;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.realweather.ClientConfig;
import net.minecraft.client.multiplayer.ClientLevel;

/** Soft cloud shadows laid over the terrain (grid that follows the ground height). */
public final class ShadowRenderer {
    private static final int N = 33;           // grid points per side
    private static final float STEP = 24f;     // blocks between grid points
    private static final int[] height = new int[N * N];
    private static final float[] alpha = new float[N * N];
    private static int originX = Integer.MIN_VALUE, originZ = Integer.MIN_VALUE;
    private static long lastRefresh = -1000L;

    private ShadowRenderer() {}

    public static void clearCache() {
        originX = Integer.MIN_VALUE;
    }

    public static void draw() {
        if (!ClientConfig.CLOUD_SHADOWS.get() || ShadowCasters.n == 0) return;
        float sy = Frame.sun[1];
        if (sy < 0.10f) return;
        float strength = ClientConfig.SHADOW_STRENGTH.get().floatValue() * SkyModel.smoothstep(0.10f, 0.35f, sy);
        if (strength <= 0.01f) return;
        ClientLevel level = Frame.level;

        int ox = (int) (Math.floor(Frame.cx / STEP) * STEP) - (N / 2) * (int) STEP;
        int oz = (int) (Math.floor(Frame.cz / STEP) * STEP) - (N / 2) * (int) STEP;
        long now = ClientState.tick;
        if (ox != originX || oz != originZ || now - lastRefresh > 40) {
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    int wx = ox + i * (int) STEP, wz = oz + j * (int) STEP;
                    float h = Frame.groundY(wx, wz, Float.NaN);
                    height[i * N + j] = Float.isNaN(h) ? Integer.MIN_VALUE : (int) h;
                }
            }
            originX = ox;
            originZ = oz;
            lastRefresh = now;
        }

        float hx = -Frame.sun[0] / sy, hz = -Frame.sun[2] / sy;
        boolean anyShadow = false;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                int idx = i * N + j;
                alpha[idx] = 0f;
                if (height[idx] == Integer.MIN_VALUE) continue;
                double wx = ox + i * STEP, wz = oz + j * STEP;
                float clear = 1f;
                for (int c = 0; c < ShadowCasters.n; c++) {
                    float h = ShadowCasters.y[c] - height[idx];
                    double cx = ShadowCasters.x[c] + hx * h;
                    double cz = ShadowCasters.z[c] + hz * h;
                    float rr = ShadowCasters.r[c];
                    double dx = wx - cx, dz = wz - cz;
                    double d2 = dx * dx + dz * dz;
                    if (d2 > (double) rr * rr * 1.2) continue;
                    float d = (float) Math.sqrt(d2) / rr;
                    float cover = (1f - SkyModel.smoothstep(0.45f, 1.0f, d)) * ShadowCasters.op[c];
                    clear *= 1f - cover;
                }
                float aa = (1f - clear) * strength;
                alpha[idx] = aa;
                if (aa > 0.01f) anyShadow = true;
            }
        }
        if (!anyShadow) return;

        Gfx.texState(Gfx.WHITE, false, false, true);
        RenderSystem.enablePolygonOffset();
        RenderSystem.polygonOffset(-3f, -3f);
        BufferBuilder bb = Gfx.beginTexColor();
        float r = 0.02f, g = 0.03f, b = 0.06f;
        for (int i = 0; i < N - 1; i++) {
            for (int j = 0; j < N - 1; j++) {
                int a = i * N + j, b2 = (i + 1) * N + j, c = (i + 1) * N + j + 1, d = i * N + j + 1;
                if (alpha[a] + alpha[b2] + alpha[c] + alpha[d] < 0.02f) continue;
                if (height[a] == Integer.MIN_VALUE || height[b2] == Integer.MIN_VALUE
                        || height[c] == Integer.MIN_VALUE || height[d] == Integer.MIN_VALUE) continue;
                vtx(bb, ox + i * STEP, ox, oz, height[a], oz + j * STEP, r, g, b, alpha[a]);
                vtx(bb, ox + (i + 1) * STEP, ox, oz, height[b2], oz + j * STEP, r, g, b, alpha[b2]);
                vtx(bb, ox + (i + 1) * STEP, ox, oz, height[c], oz + (j + 1) * STEP, r, g, b, alpha[c]);
                vtx(bb, ox + i * STEP, ox, oz, height[d], oz + (j + 1) * STEP, r, g, b, alpha[d]);
            }
        }
        Gfx.flush(bb);
        RenderSystem.polygonOffset(0f, 0f);
        RenderSystem.disablePolygonOffset();
        Gfx.resetState();
    }

    private static void vtx(BufferBuilder bb, float wx, int unusedA, int unusedB, int h, float wz,
                            float r, float g, float b, float a) {
        float x = (float) (wx - Frame.cx);
        float y = (float) (h + 0.05 - Frame.cy);
        float z = (float) (wz - Frame.cz);
        Gfx.vert(bb, x, y, z, 0.5f, 0.5f, r, g, b, a);
    }
}

package com.realweather.client;

/** Clouds that cast a shadow this frame (filled by the cloud emitters, used by ShadowRenderer). */
public final class ShadowCasters {
    private static final int MAX = 512;
    public static final double[] x = new double[MAX], z = new double[MAX];
    public static final float[] y = new float[MAX], r = new float[MAX], op = new float[MAX];
    public static int n;

    private ShadowCasters() {}

    public static void clear() {
        n = 0;
    }

    public static void add(double wx, float wy, double wz, float radius, float opacity) {
        if (n >= MAX || opacity <= 0.01f || radius <= 1f) return;
        x[n] = wx;
        y[n] = wy;
        z[n] = wz;
        r[n] = radius;
        op[n] = opacity;
        n++;
    }
}

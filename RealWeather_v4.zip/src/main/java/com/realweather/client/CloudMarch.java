package com.realweather.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.realweather.ClientConfig;
import com.realweather.Config;
import com.realweather.RealWeather;
import com.realweather.storm.StormData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Solid volumetric clouds: one ray-marching shader draws everyday clouds, storm tower, anvil, wall cloud and the tornado
 * funnel from a density field. It runs at reduced resolution into its own target and is blended over the scene.
 */
public final class CloudMarch {
    private static final double WRAP = 393216.0;
    private static final int[] STEPS = {44, 64, 90, 120};
    private static TextureTarget low;
    public static boolean broken = false;

    private CloudMarch() {}

    public static boolean available() {
        return !broken && RWShaders.cloud != null && RWShaders.blit != null;
    }

    private static void set4(ShaderInstance sh, String name, float a, float b, float c, float d) {
        sh.safeGetUniform(name).set(a, b, c, d);
    }

    public static void render(Matrix4f projection) {
        try {
            doRender(projection);
        } catch (Throwable t) {
            broken = true;
            RealWeather.LOGGER.error("RealWeather: volumetric clouds failed, switching to the sprite clouds", t);
            Gfx.resetState();
        }
    }

    private static void doRender(Matrix4f projection) {
        Minecraft mc = Minecraft.getInstance();
        RenderTarget main = mc.getMainRenderTarget();
        float scale = ClientConfig.CLOUD_RESOLUTION.get().floatValue();
        int w = Math.max(32, (int) (main.width * scale));
        int h = Math.max(32, (int) (main.height * scale));
        if (low == null) {
            low = new TextureTarget(w, h, false, Minecraft.ON_OSX);
            low.setClearColor(0f, 0f, 0f, 0f);
            low.setFilterMode(9729);
        } else if (low.width != w || low.height != h) {
            low.resize(w, h, Minecraft.ON_OSX);
            low.setClearColor(0f, 0f, 0f, 0f);
            low.setFilterMode(9729);
        }

        ShaderInstance sh = RWShaders.cloud;
        Matrix4f inv = new Matrix4f(projection).mul(Frame.modelView).invert(new Matrix4f());
        sh.safeGetUniform("InvViewProj").set(inv);

        double cxw = Frame.cx - Frame.windOffX;
        double czw = Frame.cz - Frame.windOffZ;
        cxw -= Math.floor(cxw / WRAP) * WRAP;
        czw -= Math.floor(czw / WRAP) * WRAP;
        set4(sh, "CamPos", (float) cxw, (float) Frame.cy, (float) czw, Frame.time);

        // light: sun by day, moon by night
        float sx = Frame.sun[0], sy = Frame.sun[1], sz = Frame.sun[2];
        float sunInt = Frame.sunI;
        float cr = Frame.sunCol[0], cg = Frame.sunCol[1], cb = Frame.sunCol[2];
        if (sy < -0.10f) {
            sx = -sx;
            sy = -sy;
            sz = -sz;
            sunInt = 0.30f * SkyModel.smoothstep(-0.10f, -0.30f, Frame.sun[1]);
            cr = 0.40f;
            cg = 0.48f;
            cb = 0.75f;
        }
        set4(sh, "SunDir", sx, sy, sz, sunInt);
        set4(sh, "SunCol", cr, cg, cb, Frame.dayF);
        float stormDim = 1f - ClientState.skyStorm * 0.30f * ClientConfig.STORM_DARKNESS.get().floatValue();
        set4(sh, "AmbCol", Frame.ambient[0] * stormDim, Frame.ambient[1] * stormDim, Frame.ambient[2] * stormDim, Frame.dusk);
        float shadowStrength = ClientConfig.CLOUD_SHADOWS.get() ? ClientConfig.SHADOW_STRENGTH.get().floatValue() : 0f;
        set4(sh, "HorCol", Frame.horizon[0], Frame.horizon[1], Frame.horizon[2], shadowStrength);

        float cover = AmbientClouds.moodCover * AmbientClouds.cumF * ClientConfig.CLOUD_COVERAGE.get().floatValue();
        cover = Math.max(0f, Math.min(1f, 0.12f + 1.0f * cover));
        if (AmbientClouds.moodCover * AmbientClouds.cumF * ClientConfig.CLOUD_COVERAGE.get().floatValue() < 0.02f) {
            cover = 0f;
        }
        float cong = Math.min(1f, AmbientClouds.moodCong * AmbientClouds.congBoost);
        float strat = Math.min(1f, AmbientClouds.moodStrat * (0.45f + 0.55f * Math.min(1f, AmbientClouds.stratTime / 0.6f)) * 1.3f)
                * ClientConfig.CLOUD_COVERAGE.get().floatValue();
        strat = Math.min(1f, strat);
        boolean ambient = ClientConfig.AMBIENT_CLOUDS.get();
        set4(sh, "Weather", cover, cong, strat, ambient ? 1f : 0f);
        float cumBase = Config.CLOUD_BASE_Y.get();
        set4(sh, "Layers", cumBase, 340f, cumBase - 55f, 70f);
        int q = Math.max(1, Math.min(4, ClientConfig.CLOUD_QUALITY.get()));
        set4(sh, "Params", STEPS[q - 1], Frame.drawDist, 0.75f * ClientConfig.FLASH_BRIGHTNESS.get().floatValue(),
                ClientConfig.CLOUD_SHADOWS.get() ? 1f : 0f);

        // the two storms closest to the camera
        List<StormData> list = new ArrayList<>(ClientState.storms);
        list.sort((a, b) -> Double.compare(dist2(a), dist2(b)));
        for (int i = 0; i < 2; i++) {
            if (i < list.size()) {
                setStorm(sh, i, list.get(i));
            } else {
                clearStorm(sh, i);
            }
        }

        // lightning glow
        float now = ClientState.tick + Frame.partial;
        float[][] fl = new float[4][4];
        int count = 0;
        for (LightningRenderer.Flash f : ClientState.flashes) {
            float lv = LightningRenderer.level(f, now);
            if (lv <= 0.02f) continue;
            float px = (float) (f.x - Frame.cx), py = f.cy, pz = (float) (f.z - Frame.cz);
            if (count < 4) {
                fl[count][0] = px;
                fl[count][1] = py;
                fl[count][2] = pz;
                fl[count][3] = lv;
                count++;
            } else {
                int weakest = 0;
                for (int k = 1; k < 4; k++) {
                    if (fl[k][3] < fl[weakest][3]) weakest = k;
                }
                if (lv > fl[weakest][3]) {
                    fl[weakest][0] = px;
                    fl[weakest][1] = py;
                    fl[weakest][2] = pz;
                    fl[weakest][3] = lv;
                }
            }
        }
        for (int k = 0; k < 4; k++) {
            set4(sh, "Flash" + k, fl[k][0], fl[k][1], fl[k][2], fl[k][3]);
        }

        // ---- pass 1: ray march into the small target
        int prevFbo = GlStateManager._getInteger(36006);
        low.bindWrite(true);
        low.clear(Minecraft.ON_OSX);
        RenderSystem.disableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShaderTexture(0, Gfx.NOISE);
        RenderSystem.setShaderTexture(1, main.getDepthTextureId());
        RenderSystem.setShader(() -> sh);
        drawQuad();

        // ---- pass 2: blend over the scene
        GlStateManager._glBindFramebuffer(36160, prevFbo);
        GlStateManager._viewport(0, 0, main.viewWidth, main.viewHeight);
        RenderSystem.enableBlend();
        RenderSystem.setShaderTexture(0, low.getColorTextureId());
        RenderSystem.setShader(() -> RWShaders.blit);
        drawQuad();
        Gfx.resetState();
    }

    private static void drawQuad() {
        BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION);
        bb.addVertex(-1f, -1f, 0f);
        bb.addVertex(1f, -1f, 0f);
        bb.addVertex(1f, 1f, 0f);
        bb.addVertex(-1f, 1f, 0f);
        MeshData mesh = bb.build();
        if (mesh != null) {
            BufferUploader.drawWithShader(mesh);
        }
    }

    private static double dist2(StormData s) {
        double dx = s.x - Frame.cx, dz = s.z - Frame.cz;
        return dx * dx + dz * dz;
    }

    private static void clearStorm(ShaderInstance sh, int i) {
        for (char k = 'A'; k <= 'G'; k++) {
            set4(sh, "Storm" + k + i, 0f, 0f, 0f, 0f);
        }
    }

    private static void setStorm(ShaderInstance sh, int i, StormData s) {
        float a = s.age + Frame.partial;
        float g1 = s.tower(a), g2 = s.anvil(a), g3 = s.mature(a), dis = s.dissipate(a);
        boolean funnel = s.hasTornado() && s.funnelLen(a) > 0.01f;
        if (g1 < 0.02f && !funnel) {
            clearStorm(sh, i);
            return;
        }
        double sx = s.x + s.vx * Frame.partial;
        double sz = s.z + s.vz * Frame.partial;
        float baseY = Config.CLOUD_BASE_Y.get() + s.baseOffsetY();
        float dissFade = 1f - dis * 0.9f;
        set4(sh, "StormA" + i, (float) (sx - Frame.cx), (float) (sz - Frame.cz), baseY, s.towerRadius() * (1f - 0.3f * dis));
        set4(sh, "StormB" + i, g1 * dissFade, g2 * dissFade, g3, dis);
        set4(sh, "StormC" + i, s.dirX(), s.dirZ(), s.towerHeight(), s.anvilRadius());
        set4(sh, "StormD" + i, s.kind, s.size, s.wallDrop(), 1f);

        double[] tp = new double[2];
        float len = 0f, wid = 0f, rg = 0f, spawn = 0f, flare = 2.5f;
        float gy = Frame.level.getSeaLevel();
        if (s.hasTornado()) {
            s.tornadoPos(a, tp);
            tp[0] += s.vx * Frame.partial;
            tp[1] += s.vz * Frame.partial;
            gy = TornadoRenderer.ground(s, tp[0], tp[1]);
            len = s.funnelLen(a);
            wid = s.funnelWidth(a);
            int cat = Math.max(0, Math.min(5, s.category));
            rg = StormData.EF_RADIUS[cat] * wid * (0.8f + 0.2f * s.size);
            spawn = StormData.smooth((a - s.tornStart) / (0.4f * s.tornGrow));
            flare = 3.6f - 0.38f * cat;
            set4(sh, "StormG" + i, flare, cat, 0f, 0f);
            // tornado position relative to the storm centre
            set4(sh, "StormE" + i, (float) (tp[0] - sx), (float) (tp[1] - sz), gy, baseY - 0.8f * s.wallDrop());
        } else {
            set4(sh, "StormG" + i, flare, 0f, 0f, 0f);
            // wall cloud position still needed for supercells without tornado
            double ox = -s.dirX() * 0.15 * s.towerRadius() - s.dirZ() * 0.28 * s.towerRadius();
            double oz = -s.dirZ() * 0.15 * s.towerRadius() + s.dirX() * 0.28 * s.towerRadius();
            set4(sh, "StormE" + i, (float) ox, (float) oz, gy, baseY - 0.8f * s.wallDrop());
        }
        set4(sh, "StormF" + i, len, wid, rg, spawn);
    }
}

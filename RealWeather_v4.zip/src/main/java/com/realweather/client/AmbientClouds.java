package com.realweather.client;

import com.realweather.ClientConfig;
import com.realweather.Config;
import com.realweather.storm.StormData;
import net.minecraft.client.multiplayer.ClientLevel;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * Everyday clouds: cumulus humilis / mediocris / congestus (cauliflower), stratocumulus and stratus. Which ones show up
 * depends on the "mood" of the day and on the time of day (thin cirrus in the morning, cumulus growing towards the evening).
 */
public final class AmbientClouds {
    private static final int HUMILIS = 0, MEDIOCRIS = 1, CONGESTUS = 2, STRATOCU = 3, STRATUS = 4;
    private static final double CELL = 900.0;

    private static final float[] COVER = {0.12f, 0.26f, 0.42f, 0.24f, 0.08f, 0.30f};
    private static final float[] STRAT = {0.00f, 0.05f, 0.10f, 0.00f, 0.85f, 0.22f};
    private static final float[] CONG = {0.00f, 0.08f, 0.30f, 0.75f, 0.00f, 0.10f};
    private static final float[] OVER = {0.00f, 0.00f, 0.05f, 0.05f, 0.90f, 0.20f};
    private static final float[] CIRR = {0.70f, 0.45f, 0.30f, 0.25f, 0.15f, 0.50f};

    // current weather mood (updated every tick)
    public static float moodCover, moodStrat, moodCong, moodOver, moodCirr;
    public static float cumF = 0.5f, stratTime = 0.3f, cirrusAmt = 0.3f, congBoost = 1f;

    private static final class Model {
        PuffSet p;
        float R, alpha, shadowOp, baseOff;
    }

    private static final Map<Long, Model> CACHE = new HashMap<>();

    private AmbientClouds() {}

    public static void clearCache() {
        CACHE.clear();
    }

    // ------------------------------------------------------------------ mood
    private static long mixHash(long h) {
        h ^= (h >>> 33);
        h *= 0xFF51AFD7ED558CCDL;
        h ^= (h >>> 33);
        h *= 0xC4CEB9FE1A85EC53L;
        h ^= (h >>> 33);
        return h;
    }

    private static float rnd(long h, int salt) {
        long x = mixHash(h + salt * 0x9E3779B97F4A7C15L);
        return (x >>> 40) / (float) (1L << 24);
    }

    private static int moodOf(long seed, long day) {
        float u = rnd(seed ^ (day * 0x632BE59BD9B4E019L), 77);
        if (u < 0.15f) return 0;
        if (u < 0.40f) return 1;
        if (u < 0.62f) return 2;
        if (u < 0.75f) return 3;
        if (u < 0.87f) return 4;
        return 5;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public static void update(ClientLevel level) {
        long dt = level.getDayTime();
        long day = Math.floorDiv(dt, 24000L);
        float t = (float) Math.floorMod(dt, 24000L);
        int m0 = moodOf(ClientState.worldSeed, day);
        int m1 = moodOf(ClientState.worldSeed, day + 1);
        float w = SkyModel.smoothstep(17000f, 23500f, t);
        moodCover = lerp(COVER[m0], COVER[m1], w);
        moodStrat = lerp(STRAT[m0], STRAT[m1], w);
        moodCong = lerp(CONG[m0], CONG[m1], w);
        moodOver = lerp(OVER[m0], OVER[m1], w);
        moodCirr = lerp(CIRR[m0], CIRR[m1], w);

        float up = SkyModel.smoothstep(500f, 4500f, t);
        float down = SkyModel.smoothstep(11000f, 15500f, t);
        cumF = 0.10f + 0.90f * up * (1f - 0.85f * down);
        if (t > 20000f) {
            cumF = lerp(cumF, 0.10f, SkyModel.smoothstep(20000f, 23500f, t));
        }
        float morning = 0.60f * (1f - SkyModel.smoothstep(1500f, 7000f, t));
        float night = 0.25f * SkyModel.smoothstep(15000f, 19000f, t) * (1f - SkyModel.smoothstep(21000f, 24000f, t));
        float predawn = 0.60f * SkyModel.smoothstep(21500f, 24000f, t);
        stratTime = Math.max(Math.max(morning, night), predawn);
        float c = 0.25f + 0.55f * (1f - SkyModel.smoothstep(1000f, 6000f, t)) + 0.55f * SkyModel.smoothstep(21500f, 24000f, t);
        cirrusAmt = Math.max(0f, Math.min(1f, c)) * moodCirr;
        congBoost = 1f + 0.5f * SkyModel.smoothstep(6000f, 10000f, t) * (1f - SkyModel.smoothstep(12500f, 14500f, t));
    }

    private static float valueNoise(double x, double y) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float fx = (float) (x - xi), fy = (float) (y - yi);
        fx = fx * fx * (3f - 2f * fx);
        fy = fy * fy * (3f - 2f * fy);
        float a = rnd(xi * 73856093L ^ yi * 19349663L, 5);
        float b = rnd((xi + 1) * 73856093L ^ yi * 19349663L, 5);
        float c = rnd(xi * 73856093L ^ (yi + 1) * 19349663L, 5);
        float d = rnd((xi + 1) * 73856093L ^ (yi + 1) * 19349663L, 5);
        return lerp(lerp(a, b, fx), lerp(c, d, fx), fy);
    }

    // ------------------------------------------------------------------ models
    private static Model model(long key, int type, long seed, float q) {
        Model m = CACHE.get(key);
        if (m == null) {
            if (CACHE.size() > 900) {
                CACHE.clear();
            }
            m = build(type, seed, q);
            CACHE.put(key, m);
        }
        return m;
    }

    private static Model build(int type, long seed, float q) {
        Random r = new Random(seed);
        float R, hf, alpha, baseDark, shadow, baseOff, flat;
        int lumps;
        switch (type) {
            case HUMILIS:
                R = 120f + 110f * r.nextFloat(); hf = 0.38f; lumps = 2 + r.nextInt(2);
                alpha = 0.80f; baseDark = 0.30f; shadow = 0.35f; baseOff = 0f; flat = 0.9f;
                break;
            case MEDIOCRIS:
                R = 190f + 150f * r.nextFloat(); hf = 0.75f; lumps = 3 + r.nextInt(3);
                alpha = 0.85f; baseDark = 0.32f; shadow = 0.50f; baseOff = 0f; flat = 0.9f;
                break;
            case CONGESTUS:
                R = 250f + 180f * r.nextFloat(); hf = 1.5f; lumps = 4 + r.nextInt(3);
                alpha = 0.88f; baseDark = 0.38f; shadow = 0.65f; baseOff = -10f; flat = 0.9f;
                break;
            case STRATOCU:
                R = 420f + 220f * r.nextFloat(); hf = 0.16f; lumps = 5 + r.nextInt(4);
                alpha = 0.66f; baseDark = 0.30f; shadow = 0.40f; baseOff = -25f; flat = 0.40f;
                break;
            default:
                R = 800f + 400f * r.nextFloat(); hf = 0.05f; lumps = 6 + r.nextInt(4);
                alpha = 0.50f; baseDark = 0.22f; shadow = 0.30f; baseOff = -50f; flat = 0.28f;
                break;
        }
        boolean strat = type >= STRATOCU;
        float yscale = strat ? 0.25f : 1f;
        float H = R * hf * (0.85f + 0.3f * r.nextFloat());
        float qs = (float) (1.0 / Math.pow(q, 0.25));
        PuffSet P = new PuffSet(700);

        for (int l = 0; l < lumps; l++) {
            float lr = R * (0.30f + 0.22f * r.nextFloat());
            float ang = r.nextFloat() * 6.2831855f;
            float rad = lumps > 1 ? (float) Math.sqrt(r.nextFloat()) * R * 0.55f : 0f;
            float cx = (float) Math.cos(ang) * rad, cz = (float) Math.sin(ang) * rad;
            float centrality = 1f - rad / (R * 0.6f);
            float lh = H * (0.45f + 0.55f * centrality) * (0.75f + 0.4f * r.nextFloat());
            int K = Math.max(2, (int) (lh / lr * 2.2f) + 2);
            if (strat) K = 2;
            for (int k = 0; k < K; k++) {
                float t = (k + 0.5f) / K;
                float yc = lh * t * 0.9f + lr * 0.35f * yscale;
                float rb = lr * (0.62f + 0.5f * (float) Math.sin(Math.PI * (0.12f + 0.76f * t)));
                float jx = (r.nextFloat() - 0.5f) * lr * 0.35f, jz = (r.nextFloat() - 0.5f) * lr * 0.35f;
                int per = Math.max(4, (int) ((4 + rb / R * 12) * q * (strat ? 0.8f : 1f)));
                for (int j = 0; j < per; j++) {
                    float az = r.nextFloat() * 6.2831855f;
                    float el = (r.nextFloat() * 1.15f - 0.25f) * 1.5707964f;
                    float dx = (float) (Math.cos(el) * Math.cos(az));
                    float dy = (float) Math.sin(el);
                    float dz = (float) (Math.cos(el) * Math.sin(az));
                    float x = cx + jx + dx * rb;
                    float y = yc + dy * rb * 0.85f * yscale;
                    float z = cz + jz + dz * rb;
                    float size = rb * (0.50f + 0.38f * r.nextFloat()) * (strat ? 0.9f : 1f) * qs;
                    float ox = x, oy = y - H * 0.4f, oz = z;
                    float ol = (float) Math.sqrt(ox * ox + oy * oy + oz * oz) + 1e-4f;
                    float nx = dx * 0.65f + ox / ol * 0.35f;
                    float ny = dy * 0.65f + oy / ol * 0.35f;
                    float nz = dz * 0.65f + oz / ol * 0.35f;
                    float hfv = y / (H + lr);
                    float yy = Math.max(y, size * flat * 0.55f);
                    P.add(x, yy, z, size, flat, nx, ny, nz, hfv, 0.04f + 0.10f * (1f - hfv), hfv * 0.8f, 0, r);
                }
                P.add(cx + jx, Math.max(yc, rb * 0.2f), cz + jz, rb * 0.9f * qs, flat, 0f, 0.5f, 0f,
                        yc / (H + lr), 0.18f, yc / (H + lr) * 0.8f, 0, r);
            }
        }
        int nb = (int) ((6 + R * 0.05f) * q);
        for (int i = 0; i < nb; i++) {
            float ang = r.nextFloat() * 6.2831855f;
            float rad = (float) Math.sqrt(r.nextFloat()) * R * 0.72f;
            float size = R * (strat ? 0.12f + 0.10f * r.nextFloat() : 0.16f + 0.16f * r.nextFloat()) * qs;
            P.add((float) Math.cos(ang) * rad, size * 0.2f, (float) Math.sin(ang) * rad, size, strat ? 0.22f : 0.35f,
                    0f, -1f, 0f, 0f, baseDark, 0.05f * rad / R, 0, r);
        }
        Model m = new Model();
        m.p = P;
        m.R = R;
        m.alpha = alpha;
        m.shadowOp = shadow;
        m.baseOff = baseOff;
        return m;
    }

    // ------------------------------------------------------------------ emit
    public static void emit() {
        float q = ClientConfig.qualityFactor();
        int qi = ClientConfig.CLOUD_QUALITY.get();
        float cov = ClientConfig.CLOUD_COVERAGE.get().floatValue();
        float baseY0 = Config.CLOUD_BASE_Y.get();
        long seed = ClientState.worldSeed;
        double lx = Frame.cx - Frame.windOffX;
        double lz = Frame.cz - Frame.windOffZ;
        int range = Math.min(9, (int) Math.ceil(Frame.drawDist / CELL) + 1);
        int ci = (int) Math.floor(lx / CELL), cj = (int) Math.floor(lz / CELL);

        for (int i = ci - range; i <= ci + range; i++) {
            for (int j = cj - range; j <= cj + range; j++) {
                long h = mixHash(seed ^ (i * 0x9E3779B1L) ^ (j * 0x85EBCA77L << 7));
                // --- cumulus slot
                float u1 = rnd(h, 1);
                float region = valueNoise(i * 0.21 + (seed & 127), j * 0.21);
                float coverHere = moodCover * cumF * cov * (0.35f + 1.3f * region);
                float m = coverHere - u1;
                if (m > 0f) {
                    float u3 = rnd(h, 3);
                    float pc = Math.min(0.9f, moodCong * congBoost);
                    int type = u3 < pc ? CONGESTUS : (u3 < pc + 0.5f * (1f - pc) ? MEDIOCRIS : HUMILIS);
                    emitCloud(i, j, 0, type, h, m / 0.07f, rnd(h, 5), rnd(h, 6), baseY0, q, qi);
                }
                // --- layered slot
                float u2 = rnd(h, 2);
                float covS = Math.min(1f, moodStrat * (0.45f + 0.55f * Math.min(1f, stratTime / 0.6f)) * 1.3f) * cov;
                float m2 = covS - u2;
                if (m2 > 0f) {
                    int type = rnd(h, 4) < 0.5f ? STRATOCU : STRATUS;
                    emitCloud(i, j, 1, type, h ^ 0x1234567L, m2 / 0.07f, rnd(h, 7), rnd(h, 8), baseY0, q, qi);
                }
            }
        }
    }

    private static void emitCloud(int i, int j, int slot, int type, long h, float growth, float jx, float jz,
                                  float baseY0, float q, int qi) {
        double cx = (i + 0.2 + 0.6 * jx) * CELL + Frame.windOffX;
        double cz = (j + 0.2 + 0.6 * jz) * CELL + Frame.windOffZ;
        double ddx = cx - Frame.cx, ddz = cz - Frame.cz;
        double d = Math.sqrt(ddx * ddx + ddz * ddz);
        float approxR = type >= STRATUS ? 1200f : (type == STRATOCU ? 650f : 430f);
        if (d > Frame.drawDist + approxR) return;

        float sc = Math.min(1f, Math.max(0f, growth));
        sc = StormData.smooth(sc);

        // storms push ordinary clouds away and darken the ones around them
        float supp = 1f, dark = 0f;
        for (StormData s : ClientState.storms) {
            float a = s.age + Frame.partial;
            float g1 = s.tower(a), g2 = s.anvil(a);
            if (g1 < 0.2f) continue;
            float R = s.anvilRadius() * Math.max(0.2f, g2);
            double dx = cx - s.x, dz = cz - s.z;
            float dd = (float) Math.sqrt(dx * dx + dz * dz);
            if (g2 > 0.08f) {
                supp *= SkyModel.smoothstep(0.30f * R, 0.95f * R, dd);
            }
            dark = Math.max(dark, 0.55f * (1f - SkyModel.smoothstep(0.8f * R, 2.2f * R, dd)) * g1);
        }
        sc *= supp;
        if (sc < 0.04f) return;

        long key = ((long) (i & 0xFFFFFF) << 40) | ((long) (j & 0xFFFFFF) << 16) | ((long) slot << 12) | ((long) type << 4) | qi;
        Model md = model(key, type, h * 31 + type, q);
        float baseY = baseY0 + md.baseOff + (rnd(h, 9) - 0.5f) * 20f;
        float hs = 0.45f + 0.55f * sc;
        float vs = 0.30f + 0.70f * sc;
        PuffSet P = md.p;
        for (int k = 0; k < P.n; k++) {
            float v = StormData.smooth((sc * 1.15f - P.ap[k]) / 0.25f);
            if (v <= 0.01f) continue;
            Puffs.emit(cx + P.x[k] * hs, baseY + P.y[k] * vs, cz + P.z[k] * hs,
                    P.size[k] * hs * (0.5f + 0.5f * v), P.flat[k], P.nx[k], P.ny[k], P.nz[k], P.hf[k],
                    P.dark[k] + dark, md.alpha * v, P.rot[k], P.variant[k]);
        }
        ShadowCasters.add(cx, baseY, cz, md.R * 0.85f * hs, md.shadowOp * sc);
    }
}

package com.realweather.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.ShaderInstance;

/** Full sky dome drawn over the vanilla sky: gradient, dusk glow, sun, moon, stars, cirrus, storm tint (all in a shader). */
public final class SkyRenderer {
    private static final int RINGS = 24, SEGS = 36;
    private static final float RADIUS = 48f;
    private static final float[] horizon = new float[3];

    private SkyRenderer() {}

    private static float elev(int i) {
        // from -25 degrees to +90 degrees
        float t = i / (float) RINGS;
        return (float) Math.toRadians(-25.0 + 115.0 * t);
    }

    public static void draw() {
        Gfx.beginView(Frame.modelView);
        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();

        ShaderInstance sh = RWShaders.sky;
        if (sh != null) {
            float time = Frame.time / 20f;
            sh.safeGetUniform("SunDir").set(Frame.sun[0], Frame.sun[1], Frame.sun[2]);
            sh.safeGetUniform("Params").set(time, ClientState.skyStorm, AmbientClouds.cirrusAmt * (1f - ClientState.skyStorm),
                    ClientState.skyFlash);
            sh.safeGetUniform("Params2").set(Frame.windX, Frame.windZ, ClientState.overcast, 0f);
            RenderSystem.setShader(() -> sh);
            BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION);
            for (int i = 0; i < RINGS; i++) {
                float e0 = elev(i), e1 = elev(i + 1);
                for (int j = 0; j < SEGS; j++) {
                    float a0 = j * (6.2831855f / SEGS), a1 = (j + 1) * (6.2831855f / SEGS);
                    pos(bb, e0, a0);
                    pos(bb, e0, a1);
                    pos(bb, e1, a1);
                    pos(bb, e1, a0);
                }
            }
            MeshData mesh = bb.build();
            if (mesh != null) {
                BufferUploader.drawWithShader(mesh);
            }
        } else {
            // fallback: simple vertex-coloured gradient (no sun/stars)
            SkyModel.horizon(Frame.sun[1], ClientState.skyStorm, ClientState.overcast, horizon);
            float day = Frame.dayF;
            float zr = (0.006f + (0.16f - 0.006f) * day), zg = (0.010f + (0.36f - 0.010f) * day), zb = (0.030f + (0.78f - 0.030f) * day);
            RenderSystem.setShader(GameRenderer::getPositionColorShader);
            BufferBuilder bb = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
            for (int i = 0; i < RINGS; i++) {
                float e0 = elev(i), e1 = elev(i + 1);
                float t0 = (float) Math.pow(Math.max(0f, Math.sin(e0)), 0.5), t1 = (float) Math.pow(Math.max(0f, Math.sin(e1)), 0.5);
                for (int j = 0; j < SEGS; j++) {
                    float a0 = j * (6.2831855f / SEGS), a1 = (j + 1) * (6.2831855f / SEGS);
                    col(bb, e0, a0, t0, zr, zg, zb);
                    col(bb, e0, a1, t0, zr, zg, zb);
                    col(bb, e1, a1, t1, zr, zg, zb);
                    col(bb, e1, a0, t1, zr, zg, zb);
                }
            }
            MeshData mesh = bb.build();
            if (mesh != null) {
                BufferUploader.drawWithShader(mesh);
            }
        }
        Gfx.endView();
        Gfx.resetState();
    }

    private static void pos(BufferBuilder bb, float e, float a) {
        float ce = (float) Math.cos(e);
        bb.addVertex(RADIUS * ce * (float) Math.cos(a), RADIUS * (float) Math.sin(e), RADIUS * ce * (float) Math.sin(a));
    }

    private static void col(BufferBuilder bb, float e, float a, float t, float zr, float zg, float zb) {
        float ce = (float) Math.cos(e);
        float r = horizon[0] + (zr - horizon[0]) * t;
        float g = horizon[1] + (zg - horizon[1]) * t;
        float b = horizon[2] + (zb - horizon[2]) * t;
        bb.addVertex(RADIUS * ce * (float) Math.cos(a), RADIUS * (float) Math.sin(e), RADIUS * ce * (float) Math.sin(a))
                .setColor(Gfx.c8(r), Gfx.c8(g), Gfx.c8(b), 255);
    }
}

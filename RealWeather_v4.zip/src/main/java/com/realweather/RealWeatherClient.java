package com.realweather;

import com.realweather.client.ClientEvents;
import com.realweather.client.RWShaders;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = RealWeather.MODID, dist = Dist.CLIENT)
public class RealWeatherClient {
    public RealWeatherClient(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        modBus.addListener(RWShaders::onRegisterShaders);
        ClientEvents.register(NeoForge.EVENT_BUS);
    }
}

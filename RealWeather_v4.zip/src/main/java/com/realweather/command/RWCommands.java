package com.realweather.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.realweather.Config;
import com.realweather.storm.StormData;
import com.realweather.storm.StormManager;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

public final class RWCommands {
    private static final String[] CATS = {"EF0", "EF1", "EF2", "EF3", "EF4", "EF5", "auto", "none"};
    private static final String[] KINDS = {"cell", "supercell", "squall", "dry"};

    private RWCommands() {}

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("realweather")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("storm")
                        .executes(c -> spawn(c, false, StormData.KIND_CELL, true))
                        .then(Commands.literal("fast").executes(c -> spawn(c, true, StormData.KIND_CELL, true)))
                        .then(Commands.argument("type", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(KINDS, b))
                                .executes(c -> spawn(c, false, parseKind(StringArgumentType.getString(c, "type")), false))
                                .then(Commands.literal("fast")
                                        .executes(c -> spawn(c, true, parseKind(StringArgumentType.getString(c, "type")), false)))))
                .then(Commands.literal("tornado")
                        .then(Commands.argument("category", StringArgumentType.word())
                                .suggests((c, b) -> SharedSuggestionProvider.suggest(CATS, b))
                                .executes(c -> tornado(c, StringArgumentType.getString(c, "category")))))
                .then(Commands.literal("clear").executes(RWCommands::clear))
                .then(Commands.literal("status").executes(RWCommands::status))
                .then(Commands.literal("speed")
                        .then(Commands.argument("multiplier", FloatArgumentType.floatArg(0.2f, 20f))
                                .executes(c -> speed(c, FloatArgumentType.getFloat(c, "multiplier"))))));
    }

    private static int parseKind(String s) {
        s = s.toLowerCase();
        if (s.startsWith("super")) return StormData.KIND_SUPERCELL;
        if (s.startsWith("squall") || s.startsWith("line")) return StormData.KIND_SQUALL;
        if (s.startsWith("dry")) return StormData.KIND_DRY;
        return StormData.KIND_CELL;
    }

    private static ServerLevel overworld(CommandContext<CommandSourceStack> c) {
        ServerLevel l = c.getSource().getServer().getLevel(Level.OVERWORLD);
        return l;
    }

    private static int spawn(CommandContext<CommandSourceStack> c, boolean fast, int kind, boolean random) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        StormManager m = StormManager.INSTANCE;
        int k = kind;
        if (random) {
            k = m.randomKind();
        }
        StormData s = m.spawnNear(level, p, fast, -1, k);
        m.syncAll(level);
        c.getSource().sendSuccess(() -> Component.literal("Storm (" + StormData.KIND_NAMES[s.kind] + ") formed about "
                + (int) Math.hypot(s.x - p.getX(), s.z - p.getZ()) + " blocks away"
                + (fast ? " (fast mode)" : "") + "."), true);
        return 1;
    }

    private static int tornado(CommandContext<CommandSourceStack> c, String arg) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        StormManager m = StormManager.INSTANCE;
        String a = arg.toLowerCase();
        int cat;
        if (a.equals("auto")) {
            cat = -2;
        } else if (a.equals("none")) {
            cat = -1;
        } else {
            String digits = a.replace("ef", "").replace("f", "");
            try {
                cat = Integer.parseInt(digits.trim());
            } catch (NumberFormatException ex) {
                c.getSource().sendFailure(Component.literal("Use EF0..EF5, auto or none"));
                return 0;
            }
            if (cat < 0 || cat > 5) {
                c.getSource().sendFailure(Component.literal("Category must be EF0..EF5"));
                return 0;
            }
        }
        m.forcedCategory = cat;
        if (cat == -2) {
            c.getSource().sendSuccess(() -> Component.literal("Tornado category: random for new tornadoes."), true);
            return 1;
        }
        if (cat == -1) {
            for (StormData s : m.storms) {
                s.category = -1;
                s.tornStart = -1;
            }
            m.syncAll(level);
            c.getSource().sendSuccess(() -> Component.literal("Tornadoes disabled."), true);
            return 1;
        }
        StormData s = m.nearest(p.getX(), p.getZ());
        float k = (float) Config.TIME_SCALE.get().doubleValue();
        String msg;
        if (s == null || Math.hypot(s.x - p.getX(), s.z - p.getZ()) > 5000) {
            s = m.spawnNear(level, p, true, cat, StormData.KIND_SUPERCELL);
            msg = "No storm nearby - a fast supercell formed. ";
        } else if (s.hasTornado()) {
            s.category = cat;
            msg = "The tornado of the nearest storm is now ";
        } else {
            m.setupTornado(s, cat, s.anvilEnd > 6000 ? k : 8f, s.age > s.anvilEnd - 600);
            msg = "The nearest storm will make a tornado: ";
        }
        m.syncAll(level);
        final String text = msg + "EF" + cat + " (" + StormData.EF_MPH_MIN[cat] + "-" + StormData.EF_MPH_MAX[cat] + " mph).";
        c.getSource().sendSuccess(() -> Component.literal(text), true);
        return 1;
    }

    private static int clear(CommandContext<CommandSourceStack> c) {
        ServerLevel level = overworld(c);
        if (level == null) return 0;
        StormManager.INSTANCE.storms.clear();
        StormManager.INSTANCE.syncAll(level);
        c.getSource().sendSuccess(() -> Component.literal("All storms removed."), true);
        return 1;
    }

    private static int status(CommandContext<CommandSourceStack> c) {
        StormManager m = StormManager.INSTANCE;
        if (m.storms.isEmpty()) {
            c.getSource().sendSuccess(() -> Component.literal("No storms."), false);
            return 1;
        }
        for (StormData s : m.storms) {
            String stage;
            float a = s.age;
            if (s.hasTornado() && s.funnelLen(a) > 0f) stage = "tornado EF" + s.category + " " + (int) (s.funnelLen(a) * 100) + "%";
            else if (s.anvil(a) > 0.99f) stage = "full anvil";
            else if (s.anvil(a) > 0f) stage = "anvil growing " + (int) (s.anvil(a) * 100) + "%";
            else stage = "tower " + (int) (s.tower(a) * 100) + "%";
            final String line = "#" + s.id + " " + StormData.KIND_NAMES[s.kind] + " at " + (int) s.x + ", " + (int) s.z + " - " + stage
                    + (s.hasTornado() && s.funnelLen(a) <= 0f ? " (tornado planned EF" + s.category + ")" : "");
            c.getSource().sendSuccess(() -> Component.literal(line), false);
        }
        return 1;
    }

    private static int speed(CommandContext<CommandSourceStack> c, float mult) {
        Config.TIME_SCALE.set((double) mult);
        c.getSource().sendSuccess(() -> Component.literal("Storm speed multiplier for new storms: " + mult), true);
        return 1;
    }
}

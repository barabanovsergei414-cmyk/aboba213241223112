# RealWeather (NeoForge 1.21.1)

Realistic weather: procedural sky (day / dusk / night / dawn, stars, moon, cirrus), volumetric clouds with several types,
huge anvil that grows out of a small cloud, storm types (cell, supercell, squall line, dry), lightning (cloud-to-ground,
in-cloud, anvil crawlers, sheet) with glow and delayed thunder, rain shafts, cloud shadows and tornadoes EF0-EF5.

## Commands (need operator rights)
- `/realweather storm` - storm of a random type forms ~1300 blocks away and comes towards you
- `/realweather storm fast` - same but everything happens about 8x faster (good for testing)
- `/realweather storm <cell|supercell|squall|dry> [fast]` - choose the storm type
- `/realweather tornado EF0..EF5` - the nearest storm gets a tornado of that category (if there is no storm a fast supercell is created)
- `/realweather tornado auto|none` - random category / no tornadoes
- `/realweather speed <0.2..20>` - life-cycle speed of new storms
- `/realweather status`, `/realweather clear`

Settings: Mods -> RealWeather -> Config (client: graphics and sound, common: storms and tornado).
Vanilla clouds are switched off while "Realistic clouds" is on (they are restored when you leave the world).

## Clouds
Clouds, the storm tower, the anvil, the wall cloud and the tornado funnel are one solid volumetric density field that is
ray-marched in a shader (like real volumetric clouds), not sprites. It renders at reduced resolution for speed.
Settings: `volumetricClouds` (turn off to use the old sprite clouds), `cloudResolution` (0.25..1.0, default 0.5),
`cloudQuality` (1..4). If the shader cannot be loaded the mod switches to the sprite clouds by itself.
